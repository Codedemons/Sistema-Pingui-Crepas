#include "GUI.h"
#include "WndPila.h"
#include "api.h"


#define btn_admin 101
#define btn_vent 102
#define btn_config 103

#define btn_crepas 104
#define btn_bebidas 105
#define btn_toppings 106
#define btn_volver 107

const char* AppName = "Pingui-Crepas";

LRESULT CALLBACK WndProcPrincipal(HWND Ventana,UINT Mensaje,WPARAM wParam,LPARAM lParam){
    static HINSTANCE Instancia = NULL;

    switch(Mensaje){
        case WM_CREATE:{
            Instancia = ((LPCREATESTRUCT)lParam)->hInstance;
            CreateWindowEx(0,"BUTTON","Admnistraccion",WS_CHILD|WS_VISIBLE|WS_BORDER|BS_PUSHBUTTON,75,33,300,200,Ventana,(HMENU)btn_admin,Instancia,NULL);
            CreateWindowEx(0,"BUTTON","Ventas",WS_CHILD|WS_VISIBLE|WS_BORDER|BS_PUSHBUTTON,438,33,300,200,Ventana,(HMENU)btn_vent,Instancia,NULL);
            CreateWindowEx(0,"BUTTON","Configuraciones",WS_CHILD|WS_VISIBLE|WS_BORDER|BS_PUSHBUTTON,75,312,300,200,Ventana,(HMENU)btn_config,Instancia,NULL);
            break;
        }
        case WM_COMMAND:{
            switch(LOWORD(wParam)){
                case btn_admin:{
                    HWND Wnd = CreateWindowEx(0,"ADMIN","Administracciones",WS_OVERLAPPEDWINDOW,100,100,680,420,Ventana,NULL,Instancia,NULL);
                    EnableWindow(WndPila_Cima(Pila),FALSE);
                    WndPila_Insertar(&Pila,Wnd);
                    ShowWindow(Wnd,SW_NORMAL);
                    break;
                }
                case btn_vent:{
                    HWND Wnd = CreateWindowEx(0,"VENTAS","Ventas",WS_OVERLAPPEDWINDOW,100,100,680,420,Ventana,NULL,Instancia,NULL);
                    EnableWindow(WndPila_Cima(Pila),FALSE);
                    WndPila_Insertar(&Pila,Wnd);
                    ShowWindow(Wnd,SW_NORMAL);
                    break;
                }
				case btn_config:{
                    HWND Wnd = CreateWindowEx(0,"CONFIG","Configuraciones",WS_OVERLAPPEDWINDOW,100,100,680,420,Ventana,NULL,Instancia,NULL);
                    EnableWindow(WndPila_Cima(Pila),FALSE);
                    WndPila_Insertar(&Pila,Wnd);
                    ShowWindow(Wnd,SW_NORMAL);
                    break;
                }
            }
            break;
        }
        case WM_CLOSE:{
            WndPila_Vaciar(&Pila);
            PostQuitMessage(0);
            break;
        }
        default:{
            return DefWindowProc(Ventana,Mensaje,wParam,lParam);
        }
    }
    return 0;
}
//Ventanas de manipulacion Principal
LRESULT CALLBACK WndProcAdmin(HWND Ventana,UINT Mensaje,WPARAM wParam,LPARAM lParam){
    static HINSTANCE Instancia = NULL;
	switch(Mensaje){
    	case WM_CREATE:{
            Instancia = ((LPCREATESTRUCT)lParam)->hInstance;
            CreateWindowEx(0,"BUTTON","Crepas",WS_CHILD|WS_VISIBLE|WS_BORDER|BS_PUSHBUTTON,66,56,244,128,Ventana,(HMENU)btn_crepas,Instancia,NULL);
            CreateWindowEx(0,"BUTTON","Bebibas",WS_CHILD|WS_VISIBLE|WS_BORDER|BS_PUSHBUTTON,371,56,244,128,Ventana,(HMENU)btn_bebidas,Instancia,NULL);
            CreateWindowEx(0,"BUTTON","Toppings",WS_CHILD|WS_VISIBLE|WS_BORDER|BS_PUSHBUTTON,66,235,244,128,Ventana,(HMENU)btn_toppings,Instancia,NULL);
            CreateWindowEx(0,"BUTTON","Volver",WS_CHILD|WS_VISIBLE|WS_BORDER|BS_PUSHBUTTON,371,235,244,128,Ventana,(HMENU)btn_volver,Instancia,NULL);
            break;
        }
    	case WM_COMMAND:{
    			switch(LOWORD(wParam)){
    				case btn_crepas:{
					DialogBox(Instancia,"DlgAgregar",Ventana,DlgAgregarProc);
					break;
				}
				}
			break;
		}
        case WM_CLOSE:{
            DestroyWindow(WndPila_QuitarCima(&Pila));
            EnableWindow(WndPila_Cima(Pila),TRUE);
            SetFocus(WndPila_Cima(Pila));
            break;
        }
        default:{
            return DefWindowProc(Ventana,Mensaje,wParam,lParam);
        }
    }
    return 0;
}

//Cuadros de dialogos de la ventana administraccion

// definiciones
#define btn_buscar_crepa  200
#define btn_Agregar_crepa  201
#define btn_Modificar_crepa  202
#define edit_Clave_crepa  203
#define edit_Nombre_crepa  204
#define edit_Tipo_crepa  205
#define edit_Descripcion_crepa  206
#define edit_Precio_crepa  207

LRESULT CALLBACK DlgAgregarProc(HWND hwnd, UINT mensaje, WPARAM wParam, LPARAM lParam){
	BOOL bSuccess = 0;
	switch(mensaje){	
		case WM_COMMAND:{
			switch(LOWORD(wParam)){
				case btn_buscar_crepa:{
						MessageBox(hwnd,"Buscando Crepa","Ejemplo",MB_OK);
					break;
				}
				case btn_Agregar_crepa:{
						MessageBox(hwnd,"Agregando Crepa","Ejemplo",MB_OK);
					break;
				}
				case btn_Modificar_crepa:{
						MessageBox(hwnd,"Modificando Crepa","Ejemplo",MB_OK);
					break;
				}

				case IDOK:{
						MessageBox(hwnd,"Aceptrar","Ejemplo",MB_OK);
					break;
				}
			}
			bSuccess = 1;
			return bSuccess;
		}
		case WM_CLOSE:{
			bSuccess = 1;
			EndDialog(hwnd,bSuccess);
			
			return ;
		}
		return bSuccess;
	}

	return bSuccess;
}





LRESULT CALLBACK WndProcVent(HWND Ventana,UINT Mensaje,WPARAM wParam,LPARAM lParam){
    static HINSTANCE Instancia = NULL;
	switch(Mensaje){
    	case WM_CREATE:{
            Instancia = ((LPCREATESTRUCT)lParam)->hInstance;
            CreateWindowEx(0,"BUTTON","Cre",WS_CHILD|WS_VISIBLE|WS_BORDER|BS_PUSHBUTTON,66,56,244,128,Ventana,(HMENU)btn_crepas,Instancia,NULL);
            CreateWindowEx(0,"BUTTON","Beb",WS_CHILD|WS_VISIBLE|WS_BORDER|BS_PUSHBUTTON,371,56,244,128,Ventana,(HMENU)btn_crepas,Instancia,NULL);
            CreateWindowEx(0,"BUTTON","Top",WS_CHILD|WS_VISIBLE|WS_BORDER|BS_PUSHBUTTON,66,235,244,128,Ventana,(HMENU)btn_crepas,Instancia,NULL);
            CreateWindowEx(0,"BUTTON","Volver",WS_CHILD|WS_VISIBLE|WS_BORDER|BS_PUSHBUTTON,371,235,244,128,Ventana,(HMENU)btn_crepas,Instancia,NULL);
            break;
        }
    	case WM_COMMAND:{
    			switch(LOWORD(wParam)){
    				case btn_crepas:{
					MessageBox(Ventana, "Aceptar!","Error!",MB_ICONEXCLAMATION|MB_OK);			
					break;
				}
				}
			break;
		}
        case WM_CLOSE:{
            DestroyWindow(WndPila_QuitarCima(&Pila));
            EnableWindow(WndPila_Cima(Pila),TRUE);
            SetFocus(WndPila_Cima(Pila));
            break;
        }
        default:{
            return DefWindowProc(Ventana,Mensaje,wParam,lParam);
        }
    }
    return 0;
}

LRESULT CALLBACK WndProcConfig(HWND Ventana,UINT Mensaje,WPARAM wParam,LPARAM lParam){
    static HINSTANCE Instancia = NULL;
	switch(Mensaje){
    	case WM_CREATE:{
            Instancia = ((LPCREATESTRUCT)lParam)->hInstance;
            CreateWindowEx(0,"BUTTON","C",WS_CHILD|WS_VISIBLE|WS_BORDER|BS_PUSHBUTTON,66,56,244,128,Ventana,(HMENU)btn_crepas,Instancia,NULL);
            CreateWindowEx(0,"BUTTON","B",WS_CHILD|WS_VISIBLE|WS_BORDER|BS_PUSHBUTTON,371,56,244,128,Ventana,(HMENU)btn_crepas,Instancia,NULL);
            CreateWindowEx(0,"BUTTON","T",WS_CHILD|WS_VISIBLE|WS_BORDER|BS_PUSHBUTTON,66,235,244,128,Ventana,(HMENU)btn_crepas,Instancia,NULL);
            CreateWindowEx(0,"BUTTON","V",WS_CHILD|WS_VISIBLE|WS_BORDER|BS_PUSHBUTTON,371,235,244,128,Ventana,(HMENU)btn_crepas,Instancia,NULL);
            break;
        }
    	case WM_COMMAND:{
    			switch(LOWORD(wParam)){
    				case btn_crepas:{
					MessageBox(Ventana, "Aceptar!","Error!",MB_ICONEXCLAMATION|MB_OK);			
					break;
				}
				}
			break;
		}
        case WM_CLOSE:{
            DestroyWindow(WndPila_QuitarCima(&Pila));
            EnableWindow(WndPila_Cima(Pila),TRUE);
            SetFocus(WndPila_Cima(Pila));
            break;
        }
        default:{
            return DefWindowProc(Ventana,Mensaje,wParam,lParam);
        }
    }
    return 0;
}

BOOL RegistrarClaseEx(UINT Estilo,HINSTANCE Instancia,LPCSTR NombreClase,LPCSTR NombreMenu,WNDPROC WndProcedimiento,HBRUSH Color){
    WNDCLASSEX wc;

    wc.style = Estilo;
    wc.cbSize = sizeof(WNDCLASSEX);
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;
    wc.hInstance = Instancia;
    wc.lpszClassName = NombreClase;
    wc.lpszMenuName = NombreMenu;
    wc.hCursor = LoadCursor(NULL,IDC_ARROW);
    wc.hIcon = LoadIcon(NULL,IDI_APPLICATION);
    wc.hIconSm = LoadIcon(NULL,IDI_APPLICATION);
    wc.lpfnWndProc = WndProcedimiento;
    wc.hbrBackground = Color;

    if(RegisterClassEx(&wc)){
        return  TRUE;
    }
    return FALSE;
}
