#ifndef API_H
#define API_H

LRESULT CALLBACK DlgAgregarProc(HWND hwnd, UINT mensaje, WPARAM wParam, LPARAM lParam);

#endif
